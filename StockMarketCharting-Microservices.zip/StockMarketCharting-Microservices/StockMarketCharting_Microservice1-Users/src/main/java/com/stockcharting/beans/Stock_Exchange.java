package com.stockcharting.beans;


import java.util.Arrays; 
import javax.persistence.Column; 
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Stock_Exchange")
public class Stock_Exchange {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String name;
	private String brief;
	private String address;
	private String remark;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBrief() {
		return brief;
	}
	public void setBrief(String brief) {
		this.brief = brief;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return String.format("Stock_Exchange [name=%s, id=%s, brief=%s, address=%s, remark=%s]", name, id, brief,
				address, remark);
	}
	
	public Stock_Exchange()
	{}
	
	public Stock_Exchange(String name, int id, String brief, String address, String remark) {
		super();
		this.name = name;
		this.id = id;
		this.brief = brief;
		this.address = address;
		this.remark = remark;
	}
	
	
}
