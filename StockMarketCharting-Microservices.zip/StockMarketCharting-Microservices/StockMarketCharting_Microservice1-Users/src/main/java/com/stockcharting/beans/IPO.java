package com.stockcharting.beans;

import java.sql.Date;  
import java.sql.Time;


import java.util.Arrays;

import javax.persistence.Column; 
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Past;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="IPO")
public class IPO {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String company_name;
	private String stock_exchange;
	private int price_per_share;
	private int total_no_of_shares;
	
	@DateTimeFormat(pattern="dd-MM-yyyy")
	@Past
	private Time open_date_time;
	private String remark;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getStock_exchange() {
		return stock_exchange;
	}
	public void setStock_exchange(String stock_exchange) {
		this.stock_exchange = stock_exchange;
	}
	public int getPrice_per_share() {
		return price_per_share;
	}
	public void setPrice_per_share(int price_per_share) {
		this.price_per_share = price_per_share;
	}
	public int getTotal_no_of_shares() {
		return total_no_of_shares;
	}
	public void setTotal_no_of_shares(int total_no_of_shares) {
		this.total_no_of_shares = total_no_of_shares;
	}
	public Time getOpen_date_time() {
		return open_date_time;
	}
	public void setOpen_date_time(Time open_date_time) {
		this.open_date_time = open_date_time;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return String.format(
				"IPO [id=%s, company_name=%s, stock_exchange=%s, price_per_share=%s, total_no_of_shares=%s, open_date_time=%s, remark=%s]",
				id, company_name, stock_exchange, price_per_share, total_no_of_shares, open_date_time, remark);
	}
	
	public IPO()
	{}
	
	
	public IPO(int id, String company_name, String stock_exchange, int price_per_share, int total_no_of_shares,
			Time open_date_time, String remark) {
		super();
		this.id = id;
		this.company_name = company_name;
		this.stock_exchange = stock_exchange;
		this.price_per_share = price_per_share;
		this.total_no_of_shares = total_no_of_shares;
		this.open_date_time = open_date_time;
		this.remark = remark;
	}
	
}
