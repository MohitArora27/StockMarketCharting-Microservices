package com.stc.service;

public interface StockService {

}