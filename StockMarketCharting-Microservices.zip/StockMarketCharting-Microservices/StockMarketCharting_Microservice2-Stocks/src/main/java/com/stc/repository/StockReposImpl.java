package com.stc.repository;

public class StockReposImpl implements StockRepos {

}
