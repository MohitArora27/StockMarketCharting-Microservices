package com.stc.entity;

import java.util.Arrays;
import javax.persistence.Column; 
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Company {

	@Id
	@Column(name="name")
	private String name;
	
	@Column(name="turnover")
	private int turnover;
	
	@Column(name="ceo")
	private String ceo;
	
	@Column(name="board_of_directors")
	private String[] board_of_directors;
	
	@Column(name="listed_stock_exchange")
	private String[] listed_stock_exchange;

	@Column(name="sector")
	private String sector;
	
	@Column(name="brief_writing")
	private String brief_writing;
	
	@Column(name="stock_code")
	private String[] stock_code;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getTurnover() {
		return turnover;
	}
	public void setTurnover(int turnover) {
		this.turnover = turnover;
	}
	public String getCeo() {
		return ceo;
	}
	public void setCeo(String ceo) {
		this.ceo = ceo;
	}
	public String[] getBoard_of_directors() {
		return board_of_directors;
	}
	public void setBoard_of_directors(String[] board_of_directors) {
		this.board_of_directors = board_of_directors;
	}
	public String[] getListed_stock_exchange() {
		return listed_stock_exchange;
	}
	public void setListed_stock_exchange(String[] listed_stock_exchange) {
		this.listed_stock_exchange = listed_stock_exchange;
	}
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getBrief_writing() {
		return brief_writing;
	}
	public void setBrief_writing(String brief_writing) {
		this.brief_writing = brief_writing;
	}
	public String[] getStock_code() {
		return stock_code;
	}
	public void setStock_code(String[] stock_code) {
		this.stock_code = stock_code;
	}
	@Override
	public String toString() {
		return String.format(
				"Company [name=%s, turnover=%s, ceo=%s, board_of_directors=%s, listed_stock_exchange=%s, sector=%s, brief_writing=%s, stock_code=%s]",
				name, turnover, ceo, Arrays.toString(board_of_directors), Arrays.toString(listed_stock_exchange),
				sector, brief_writing, Arrays.toString(stock_code));
	}
	
	public Company()
	{}
	public Company(String name, int turnover, String ceo, String[] board_of_directors, String[] listed_stock_exchange,
			String sector, String brief_writing, String[] stock_code) {
		super();
		this.name = name;
		this.turnover = turnover;
		this.ceo = ceo;
		this.board_of_directors = board_of_directors;
		this.listed_stock_exchange = listed_stock_exchange;
		this.sector = sector;
		this.brief_writing = brief_writing;
		this.stock_code = stock_code;
	}
	
}
